package com.main.interfaces;

public interface Disfrace {
  int getsusto();
}
