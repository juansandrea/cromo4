package com.main.entidades.Ninios;

public class CaramelosInsuficientesException extends Exception {

  public CaramelosInsuficientesException(String msg) {
    super(msg);
  }



}
