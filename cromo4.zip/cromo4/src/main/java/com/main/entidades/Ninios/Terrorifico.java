package com.main.entidades.Ninios;

public class Terrorifico extends Traje {
  int susto ;

  public Terrorifico(int i) {
    super();
  }

  @Override
  public int getSusto() {
    return susto = 5;
  }

  @Override
  public void setSusto(int susto) {
  }

  public Terrorifico() {
    super();
  }


}
