package com.main.entidades.Ninios;

import java.util.ArrayList;

public class Legion {

    private String nombre;
    private int poderDeSusto;

    public Legion(String nombre, int poderDeSusto, int adtitud, Traje traje, Maquillaje maquillaje, int caramelos) {
    }

    public Legion() {

    }


    public int getPoderDeSusto() {
        return poderDeSusto;
    }

    public void setPoderDeSusto(int poderDeSusto) {
        this.poderDeSusto = poderDeSusto;
    }



    public String getNombre() {
        return this.nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public  void elegirLider(ArrayList<Ninio> miembros){
        Ninio elegirLider = new Ninio();
        int mayorAdtitud = 9;


        for (Ninio esElLider : miembros)
            if (esElLider.getAdtitud() > mayorAdtitud) {
                mayorAdtitud = esElLider.getAdtitud();
                elegirLider = esElLider;

            }

        System.out.println("Es El Lider "  + elegirLider.getNombre() +" "+ elegirLider.getAdtitud());

    }

}
