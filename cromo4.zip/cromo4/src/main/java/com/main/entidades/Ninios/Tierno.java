package com.main.entidades.Ninios;

public class Tierno extends Traje{
  int susto ;

  @Override
  public int getSusto() {
    return susto = 2;
  }

  @Override
  public void setSusto(int susto) {
  }

  public Tierno() {
    super();
  }
}
